import React from 'react';

const ShopDetail = () => {
    return (
        <div>
            
        </div>
    );
}

export default ShopDetail;
